<script src="<?= base_url('assets/') ?>static/js/app.js"></script>

</body>

</html>